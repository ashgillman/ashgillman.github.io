---
title: About Ashley
author: Ashley
layout: page
evolve_full_width:
  - no
evolve_slider_type:
  - no
---
I am an engineering and IT student studying at James cook University. I created this blog to keep a record of the various projects I have participated in, and hopefully to provide help to others taking part in similar projects.

Please feel free to send me a message below.